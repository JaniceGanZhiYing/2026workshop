const GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbxkYgXFPQltNQ1REdb0wqDi4ylR3GY0AQJjNaUy5CFC5mJHayCTIZ4au6DaC3THuA6kDw/exec";

const form = document.querySelector("#registration-form");
const message = document.querySelector("#form-message");
const submitButton = form.querySelector("button");

function showMessage(text, isError = false) {
  message.textContent = text;
  message.classList.toggle("error", isError);
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  if (!GOOGLE_SCRIPT_URL) {
    showMessage("尚未設定 Google Sheet 報名網址，請先完成 Apps Script 部署。", true);
    return;
  }

  submitButton.disabled = true;
  showMessage("資料送出中...");

  try {
    const formData = new FormData(form);
    const payload = Object.fromEntries(formData.entries());

    await fetch(GOOGLE_SCRIPT_URL, {
      method: "POST",
      mode: "no-cors",
      headers: {
        "Content-Type": "text/plain;charset=utf-8"
      },
      body: JSON.stringify(payload)
    });

    form.reset();
    showMessage("已送出報名，請確認 Google Sheet 是否新增資料。");
  } catch (error) {
    showMessage("送出失敗，請稍後再試。", true);
  } finally {
    submitButton.disabled = false;
  }
});
