function doPost(e) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
  ensureHeader(sheet);

  const data = JSON.parse(e.postData.contents);

  sheet.appendRow([
    data.name || "",
    data.email || "",
    String(data.phone || ""),
    data.organization || "",
    data.jobTitle || "",
    new Date()
  ]);

  return ContentService
    .createTextOutput(JSON.stringify({ ok: true }))
    .setMimeType(ContentService.MimeType.JSON);
}

function ensureHeader(sheet) {
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(["姓名", "email", "電話", "單位", "職稱", "送出時間"]);
    sheet.getRange("C:C").setNumberFormat("@");
  }
}
